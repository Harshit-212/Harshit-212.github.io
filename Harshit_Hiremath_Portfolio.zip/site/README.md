# Harshit R. Hiremath — Research Portfolio

A static, single-page academic website. It has no build step and no runtime dependencies (Google Fonts are optional; the site falls back to system fonts).

```
index.html                                  the whole site (HTML, CSS, JS)
assets/Harshit_Hiremath_Academic_CV.pdf     downloadable CV, linked from the hero, CV and Contact sections
assets/Harshit_Hiremath_Academic_CV.docx    editable CV, linked from the CV section
cv-source/                                  data + scripts that generate both CV files
```

## Editing content

All website content lives in the `DATA` object near the bottom of `index.html`:

- `publications`: each entry has its own `status` (`published`, `presented`, `preprint`, `review`, `submitted`, `prep`, `manuscript`), `statusText`, `authors`, `venue`, links and abstract. Add a paper by copying an entry.
- `projects`, `otherProjects`, `record` (grants, awards, recognition, patent application), `skills`, `links`.
- Text wrapped in `[square brackets]` shows as a highlighted placeholder, e.g. the missing author lists for the manuscripts.

**When a status changes** (for example, the SUA diagnostic paper is submitted to ICML), update the matching entry in `index.html` **and** in `cv-source/cv_data.json`, then regenerate the CV.

## Regenerating the CV

From the `cv-source/` folder (requires Python with Playwright plus Chrome, and Node with the `docx` package):

```
python3 make_pdf.py  cv_data.json ../assets/Harshit_Hiremath_Academic_CV.pdf
node    make_docx.js cv_data.json ../assets/Harshit_Hiremath_Academic_CV.docx
```

Alternatively, edit the `.docx` in Word and export it to PDF under the same filename.

## Previewing locally

```
python3 -m http.server 8000      # then open http://localhost:8000
```

## Deploying

- **Vercel:** create a project, import the folder or a GitHub repo, choose the *Other* framework preset, and leave the build command empty.
- **GitHub Pages:** push the folder to a repository, then go to Settings → Pages → Deploy from branch (root).
- **Netlify:** drag the folder onto app.netlify.com/drop.

After deploying, replace `https://example.com/` in the `<link rel="canonical">` and `og:url` tags in `index.html` with the real address.
