const fs = require("fs");
const { Document, Packer, Paragraph, TextRun, ExternalHyperlink, TabStopType, BorderStyle,
        LevelFormat, Footer, AlignmentType, PageNumber } = require("docx");

const D = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const OUT = process.argv[3];
const SERIF = "Georgia", SANS = "Calibri";
const INK = "1D1D1B", MUTED = "5A5852", BLUE = "24466B", OLIVE = "55643A";
const W = 11906, M = 1000, RIGHT = W - 2 * M;   // A4, ~0.7in margins

const t = (text, o = {}) => new TextRun({ text, font: o.font || SERIF, size: o.size || 21, bold: o.bold,
  italics: o.italics, color: o.color || INK, characterSpacing: o.cs });
const link = (text, url, o = {}) => new ExternalHyperlink({ link: url,
  children: [new TextRun({ text, font: o.font || SERIF, size: o.size || 21, color: BLUE, italics: o.italics })] });
const tabs = [{ type: TabStopType.RIGHT, position: RIGHT }];
const date = s => s ? [new TextRun({ text: "\t" + s, font: SANS, size: 17, color: MUTED })] : [];

const H = title => new Paragraph({ keepNext: true, spacing: { before: 220, after: 90 },
  border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: "CFC9BB", space: 3 } },
  children: [t(title.toUpperCase(), { font: SANS, size: 16, bold: true, color: BLUE, cs: 30 })] });
const H3 = s => new Paragraph({ keepNext: true, spacing: { before: 100, after: 40 },
  children: [t(s, { font: SANS, size: 17, color: MUTED, bold: true })] });
const P = (children, o = {}) => new Paragraph({ tabStops: tabs, spacing: { after: o.after ?? 40, before: o.before ?? 0 },
  keepNext: o.keepNext, indent: o.indent, children });
const bullet = s => new Paragraph({ numbering: { reference: "b", level: 0 }, spacing: { after: 20 }, children: [t(s)] });

const authorRuns = list => {
  const r = [];
  list.forEach((a, i) => {
    r.push(t(a, { bold: D.me.includes(a) }));
    if (i < list.length - 2) r.push(t(", "));
    else if (i === list.length - 2) r.push(t(list.length > 2 ? ", and " : " and "));
  });
  r.push(t(". "));
  return r;
};

const kids = [];
// Header
kids.push(new Paragraph({ spacing: { after: 40 }, children: [t(D.name, { size: 44 })] }));
kids.push(new Paragraph({ spacing: { after: 100 }, children: [t(D.title.toUpperCase(), { font: SANS, size: 16, color: MUTED, cs: 10 })] }));
const cline = [t(D.location, { font: SANS, size: 17, color: MUTED })];
D.contact.forEach(c => { cline.push(t("   ·   ", { font: SANS, size: 17, color: "B5B0A4" }));
  if (c.label !== "Email") cline.push(t(c.label + " ", { font: SANS, size: 17, color: "8A867C" }));
  cline.push(link(c.text, c.url, { font: SANS, size: 17 })); });
kids.push(new Paragraph({ spacing: { after: 60 }, border: { bottom: { style: BorderStyle.SINGLE, size: 12, color: INK, space: 6 } }, children: cline }));

kids.push(H("Research Interests"), P([t(D.interests)]));

kids.push(H("Education"));
D.education.forEach(x => {
  kids.push(P([t(x.what, { bold: true }), ...date(x.when)], { after: 0, keepNext: true }));
  kids.push(P([t(x.where, { italics: true, color: MUTED })], { after: 60 }));
});

kids.push(H("Publications and Manuscripts"));
D.pubgroups.forEach(g => {
  kids.push(H3(g.h));
  g.items.forEach((p, i) => {
    const runs = [t(`[${g.prefix}${i + 1}]\t`, { font: SANS, size: 17, color: BLUE })];
    if (p.authors.length) runs.push(...authorRuns(p.authors));
    runs.push(t(`“${p.title}.” `));
    if (p.venue) runs.push(t(p.venue + " ", { italics: true }));
    p.links.forEach(l => runs.push(link(l.t, l.u)));
    kids.push(new Paragraph({ tabStops: [{ type: TabStopType.LEFT, position: 520 }], indent: { left: 520, hanging: 520 },
      spacing: { after: 0 }, keepNext: true, keepLines: true, children: runs }));
    kids.push(new Paragraph({ indent: { left: 520 }, spacing: { after: 80 },
      children: [t(p.status, { font: SANS, size: 16, color: OLIVE })] }));
  });
});
kids.push(P([t("Bold marks the CV holder. Statuses are as of November 2026; only items marked Published have appeared in a journal.", { italics: true, size: 17, color: MUTED })]));

kids.push(H("Research Experience"));
D.research.forEach(r => {
  const head = [t(r.what, { bold: true })];
  if (r.role) head.push(t(" — " + r.role, { italics: true, color: MUTED }));
  kids.push(P([...head, ...date(r.when)], { keepNext: true, after: 20 }));
  r.bullets.forEach(b => kids.push(bullet(b)));
  kids.push(new Paragraph({ spacing: { after: 40 }, children: [] }));
});

kids.push(H("Selected Projects"));
D.projects.forEach(p => {
  kids.push(P([t(p.what, { bold: true }), ...date(p.when)], { keepNext: true, after: 0 }));
  kids.push(P([t(p.text)], { after: 80 }));
});

kids.push(H("Grants and Funding"));
D.grants.forEach(g => kids.push(P([t(g.what), t("   " + g.amt, { bold: true }), ...date(g.when)], { after: 50 })));

kids.push(H("Awards and Recognition"));
D.awards.forEach(a => kids.push(P([t(a.what), ...date(a.when)], { after: 50 })));

kids.push(H("Intellectual Property"));
D.ip.forEach(x => { kids.push(P([t(x.what)], { after: 0, keepNext: true })); kids.push(P([t(x.status, { italics: true, color: MUTED })], { after: 60 })); });

kids.push(H("Technical Skills"));
D.skills.forEach(s => kids.push(new Paragraph({ tabStops: [{ type: TabStopType.LEFT, position: 1900 }],
  indent: { left: 1900, hanging: 1900 }, spacing: { after: 50 },
  children: [t(s.h + "\t", { font: SANS, size: 17, color: MUTED, bold: true }), t(s.v)] })));

kids.push(H("Professional Development"));
D.development.forEach(x => kids.push(P([t(x.what), ...date(x.when)], { after: 40 })));

const doc = new Document({
  creator: "Harshit R. Hiremath", title: "Harshit Rajshekhar Hiremath — Academic CV",
  styles: { default: { document: { run: { font: SERIF, size: 21 } } } },
  numbering: { config: [{ reference: "b", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
    style: { paragraph: { indent: { left: 360, hanging: 220 } } } }] }] },
  sections: [{
    properties: { page: { size: { width: W, height: 16838 }, margin: { top: 900, bottom: 900, left: M, right: M } } },
    footers: { default: new Footer({ children: [new Paragraph({ tabStops: tabs, children: [
      t("Harshit R. Hiremath — Curriculum Vitae", { font: SANS, size: 15, color: "8A867C" }),
      new TextRun({ text: "\tPage ", font: SANS, size: 15, color: "8A867C" }),
      new TextRun({ children: [PageNumber.CURRENT], font: SANS, size: 15, color: "8A867C" }),
      new TextRun({ text: " of ", font: SANS, size: 15, color: "8A867C" }),
      new TextRun({ children: [PageNumber.TOTAL_PAGES], font: SANS, size: 15, color: "8A867C" })] })] }) },
    children: kids
  }]
});
Packer.toBuffer(doc).then(b => { fs.writeFileSync(OUT, b); console.log("ok"); });
