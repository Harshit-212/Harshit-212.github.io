import json, html, sys
from playwright.sync_api import sync_playwright

D = json.load(open(sys.argv[1]))
out = sys.argv[2]
e = html.escape

def authors(lst):
    parts = []
    for a in lst:
        parts.append(f"<b>{e(a)}</b>" if a in D["me"] else e(a))
    if len(parts) > 2: return ", ".join(parts[:-1]) + ", and " + parts[-1]
    return " and ".join(parts)

def sec(title, body):
    return f'<section><h2>{e(title)}</h2>{body}</section>'

def row(left, right="", sub=""):
    return f'<div class="row"><div class="l">{left}{f"<div class=sub>{sub}</div>" if sub else ""}</div><div class="r">{e(right)}</div></div>'

contact = "".join(f'<div><span class=lab>{e(c["label"])}</span><a href="{e(c["url"])}">{e(c["text"])}</a></div>' for c in D["contact"])

edu = "".join(row(f"<b>{e(x['what'])}</b>", x["when"], e(x["where"])) for x in D["education"])

pubs = ""
for g in D["pubgroups"]:
    items = ""
    for i, p in enumerate(g["items"], 1):
        a = authors(p["authors"]) + ". " if p["authors"] else ""
        links = " ".join(f'<a href="{e(l["u"])}">{e(l["t"])}</a>' for l in p["links"])
        items += (f'<li><span class="tag">[{g["prefix"]}{i}]</span><div>{a}“{e(p["title"])}.” '
                  f'<i>{e(p["venue"])}</i> {links}'
                  f'<div class="status">{e(p["status"])}</div></div></li>')
    pubs += f'<h3>{e(g["h"])}</h3><ol class="pubs">{items}</ol>'
pubs += '<p class="note">Bold marks the CV holder. Statuses are as of November 2026; only items marked Published have appeared in a journal.</p>'

res = ""
for r in D["research"]:
    head = f"<b>{e(r['what'])}</b>" + (f" <span class=role>— {e(r['role'])}</span>" if r["role"] else "")
    res += f'<div class="item">{row(head, r["when"])}<ul>' + "".join(f"<li>{e(b)}</li>" for b in r["bullets"]) + "</ul></div>"

proj = "".join(f'<div class="item">{row("<b>"+e(p["what"])+"</b>", p["when"])}<p class="desc">{e(p["text"])}</p></div>' for p in D["projects"])

grants = '<table class="t">' + "".join(f'<tr><td>{e(g["what"])}</td><td class="amt">{e(g["amt"])}</td><td class="yr">{e(g["when"])}</td></tr>' for g in D["grants"]) + "</table>"
awards = '<table class="t">' + "".join(f'<tr><td>{e(a["what"])}</td><td class="yr">{e(a["when"])}</td></tr>' for a in D["awards"]) + "</table>"
ip = "".join(row(e(x["what"]), "", e(x["status"])) for x in D["ip"])
skills = '<table class="t sk">' + "".join(f'<tr><th>{e(s["h"])}</th><td>{e(s["v"])}</td></tr>' for s in D["skills"]) + "</table>"
dev = '<table class="t">' + "".join(f'<tr><td>{e(x["what"])}</td><td class="yr">{e(x["when"])}</td></tr>' for x in D["development"]) + "</table>"

css = """

*{box-sizing:border-box}
body{margin:0;font-family:'TeX Gyre Pagella','Palatino Linotype',Georgia,'DejaVu Serif',serif;font-size:10.6pt;line-height:1.38;color:#1d1d1b}
a{color:#24466b;text-decoration:none}
header{border-bottom:1.4pt solid #1d1d1b;padding-bottom:9pt;margin-bottom:4pt}
h1{font-weight:400;font-size:25pt;letter-spacing:-.2pt;margin:0;line-height:1.05}
.title{font-family:Inter,sans-serif;font-size:8.6pt;letter-spacing:.5pt;text-transform:uppercase;color:#4a4945;margin:6pt 0 0}
.contact{font-family:Inter,sans-serif;font-size:8.2pt;margin-top:9pt;display:grid;grid-template-columns:repeat(2,1fr);gap:2pt 18pt;color:#2c2c2a}.contact div{display:flex;gap:8pt}.contact .lab{width:66pt;flex:none}
.contact .lab{color:#8a867c}.dot{color:#b5b0a4;margin:0 2pt}
section{margin-top:11pt}
h2{font-family:Inter,sans-serif;font-weight:600;font-size:8.4pt;letter-spacing:1.4pt;text-transform:uppercase;color:#24466b;
   margin:0 0 5pt;padding-bottom:3pt;border-bottom:.5pt solid #cfc9bb;break-after:avoid}
h3{font-family:Inter,sans-serif;font-weight:500;font-size:8.6pt;color:#4a4945;margin:7pt 0 3pt;break-after:avoid}
.row{display:flex;justify-content:space-between;gap:14pt}
.r{font-family:Inter,sans-serif;font-size:8.4pt;color:#4a4945;white-space:nowrap;padding-top:1.5pt}
.sub{color:#4a4945;font-style:italic}
.role{font-style:italic;color:#4a4945}
.item{margin-bottom:6pt;break-inside:avoid}
ul{margin:2pt 0 0;padding-left:13pt}ul li{margin:1pt 0}
.desc{margin:1pt 0 0;color:#2c2c2a}
ol.pubs{list-style:none;margin:0;padding:0}
ol.pubs li{display:grid;grid-template-columns:28pt 1fr;margin-bottom:5pt;break-inside:avoid}
.tag{font-family:Inter,sans-serif;font-size:8pt;color:#24466b;padding-top:1.5pt}
.status{font-family:Inter,sans-serif;font-size:7.8pt;letter-spacing:.3pt;color:#55643a;margin-top:1pt}
.note{font-size:8.6pt;color:#6b685f;font-style:italic;margin:4pt 0 0}
table.t{width:100%;border-collapse:collapse}
table.t td,table.t th{padding:2.2pt 0;vertical-align:top;border-bottom:.4pt solid #e6e1d6}
table.t tr:last-child td,table.t tr:last-child th{border-bottom:0}
.amt{text-align:right;white-space:nowrap;padding-left:12pt!important;font-family:'DejaVu Serif',serif;font-size:9.6pt}
.yr{text-align:right;white-space:nowrap;width:70pt;font-family:Inter,sans-serif;font-size:8.4pt;color:#4a4945;padding-left:10pt!important}
.sk th{text-align:left;font-family:Inter,sans-serif;font-weight:500;font-size:8.4pt;color:#4a4945;width:96pt;padding-top:3pt!important}
p.int{margin:0}
"""

doc = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>{e(D['name'])} — Academic CV</title><style>{css}</style></head><body>
<header><h1>{e(D['name'])}</h1><p class="title">{e(D['title'])}</p>
<div class="contact"><div><span class=lab>Location</span>{e(D['location'])}</div>{contact}</div></header>
{sec('Research Interests', f'<p class="int">{e(D["interests"])}</p>')}
{sec('Education', edu)}
{sec('Publications and Manuscripts', pubs)}
{sec('Research Experience', res)}
{sec('Selected Projects', proj)}
{sec('Grants and Funding', grants)}
{sec('Awards and Recognition', awards)}
{sec('Intellectual Property', ip)}
{sec('Technical Skills', skills)}
{sec('Professional Development', dev)}
</body></html>"""
open(out.replace(".pdf", ".html"), "w").write(doc)
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome")
    pg = b.new_page(); pg.set_content(doc); pg.wait_for_timeout(300)
    pg.pdf(path=out, format="A4", print_background=True, display_header_footer=True,
           header_template="<span></span>",
           footer_template='<div style="width:100%;font-family:Inter,sans-serif;font-size:7.5pt;color:#8a867c;padding:0 17mm;display:flex;justify-content:space-between"><span>Harshit R. Hiremath — Curriculum Vitae</span><span>Page <span class="pageNumber"></span> of <span class="totalPages"></span></span></div>',
           margin={"top": "16mm", "bottom": "17mm", "left": "17mm", "right": "17mm"})
    b.close()
print("ok")
